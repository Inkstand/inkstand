<?php

global $CORE;

require_once DIR . "/admin/edit/edithomepage.php";

?>

