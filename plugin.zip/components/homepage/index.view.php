<?php

global $CORE;

?>

<header>
	<h2><?php echo $CORE->getSetting('site_title');?></h2>
</header>

<div class="content">
	<?php echo $CORE->getSetting('custom_homepage_content'); ?>	
</div>