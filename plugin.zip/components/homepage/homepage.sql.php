<?php

require_once 'config.php';

//sql goes here if we need it for the homepage

?>