<?php

$component = new Component();

$component->name = "New System";
$component->description = "This component is testing the new system";

?>