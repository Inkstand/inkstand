<?php

echo "This is the index view";

?>