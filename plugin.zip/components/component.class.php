<?php

class Component()
{
	public $name = "No name yet";
	public $description = "No description yet";
	public $hidden = false;
	public $editview;

}

?>