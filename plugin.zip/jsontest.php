<?php

$json = array("text" => "Blog", "url" => "http://localhost/modular/index.php/article");

echo serialize($json);

?>