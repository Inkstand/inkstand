	<div id="view-footer">
		<div class="module module1">
			<div id="social-media">
				<div >
					<a id="linkedin" target="_blank" href="https://www.linkedin.com/pub/joseph-conradt/58/19/42b"></a>
					<a id="facebook" target="_blank" href="https://www.facebook.com/joseph.conradt.9"></a>
					<a id="twitter" target="_blank" href="https://twitter.com/joeconradt"></a>
					<a id="email" href=""></a>
				</div>
			</div>
		</div>
		<div class="module module1">
			<p style="text-align:center">Copyright 2014 Joseph Conradt</p>
		</div>
		<div class="module module1">
			<ul style="text-align:center">
				<li><a href="">Contact me</a></li>
				<li><a href="">Google something</a></li>
				<li><a href="">Projects</a></li>
				<li><a href="">Dubstep</a></li>
			</ul>
		</div>
	</div>
</body>
</html>