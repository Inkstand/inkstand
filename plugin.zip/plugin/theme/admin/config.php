<?php

//layouts
$theme_layouts = array('default', 'admin');

?>