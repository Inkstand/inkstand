<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div>
		<h1>This is the layout</h1>
		<?php self::inject_view() ?>
	</div>
</body>
</html>