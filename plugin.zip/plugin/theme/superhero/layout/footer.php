	<div id="view-footer">
		<div class="module module1">

		</div>
		<div class="module module1">
			<p style="text-align:center">Copyright 2014 <?php echo $CORE->getSetting('site_title');?></p>
		</div>
		<div class="module module1">

		</div>
	</div>
	<style>
		input[type="text"], textarea, .form-control {

		  background-color : #d4d4d4; 

		}
		.navbar-form .form-control {
			background-color : #ffffff; 
		}

	</style>
</body>
</html>