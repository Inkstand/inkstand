<?php

require_once 'header.php';

?>

<div class="container">

	<div class="module module3"> 
	
	<?php

	require_once DIR . "/components/$component/$name.view.php";

	?>

	</div> 


</div>

<?php

require_once 'footer.php';

?>

