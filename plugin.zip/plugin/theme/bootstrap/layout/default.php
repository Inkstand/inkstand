<?php

require_once 'header.php';

?>


<div class="container">

	<div class="module module3"> 
	
	<?php $this->inject_view() ?>

	</div> 

</div>

<?php

require_once 'footer.php';

?>

