	<div id="view-footer">
		<div class="module module1">

		</div>
		<div class="module module1">
			<p style="text-align:center">Copyright 2014 <?php echo $CORE->getSetting('site_title');?></p>
		</div>
		<div class="module module1">

		</div>
	</div>
</body>
</html>