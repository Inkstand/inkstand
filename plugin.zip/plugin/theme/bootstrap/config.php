<?php

//layouts

$theme_layouts = array('default', 'Wide_Content', 'homepage');


?>