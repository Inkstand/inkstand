<?php

require_once '../../config.php';



$CORE->printModule("coursehome", 1);

?>