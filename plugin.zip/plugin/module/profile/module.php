<?php

$id = $MODULE->id;

?>
<div id='<?php echo $MODULE->type . $MODULE->id ?>' module="<?php echo $MODULE->id; ?>" class="module module1 module-<?php echo $MODULE->type; ?>">
	<div id="course_header" class="module_header">
		
	</div>
	<div id="course_content" class="module_content">
		<p>Test text</p>
	</div>
	<div id="course_footer" class="course_footer">

	</div>
</div>