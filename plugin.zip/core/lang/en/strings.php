<?php

$strings = array(
	"sitedescription" => "Description of this website",
);

?>